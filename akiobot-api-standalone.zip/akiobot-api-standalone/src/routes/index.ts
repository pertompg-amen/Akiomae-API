import { Router, type IRouter } from "express";
import healthRouter from "./health";
import akiocodesRouter from "./akiocodes";

const router: IRouter = Router();

router.use(healthRouter);
router.use(akiocodesRouter);

export default router;
