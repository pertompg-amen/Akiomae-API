import { Router, type IRouter } from "express";
import { readFileSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const router: IRouter = Router();

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_FILE = join(__dirname, "../data.json");

function loadData(): Record<string, unknown> {
  try {
    const raw = readFileSync(DATA_FILE, "utf-8");
    return JSON.parse(raw) as Record<string, unknown>;
  } catch {
    return {};
  }
}

// GET /api/routes — lista todos los endpoints disponibles
router.get("/routes", (_req, res) => {
  const data = loadData();
  res.json({
    endpoints: Object.keys(data).map((path) => `/api${path}`),
  });
});

// Sirve cualquier ruta definida en data.json
router.use((req, res, next) => {
  const data = loadData();

  // Buscar coincidencia exacta primero
  const path = req.path;
  if (path in data) {
    res.json(data[path]);
    return;
  }

  // Buscar coincidencia con parámetros (ej: /usuario/:id → /usuario/ezkovar)
  for (const [route, value] of Object.entries(data)) {
    const routeParts = route.split("/");
    const reqParts = path.split("/");
    if (routeParts.length !== reqParts.length) continue;

    const params: Record<string, string> = {};
    const match = routeParts.every((part, i) => {
      if (part.startsWith(":")) {
        params[part.slice(1)] = reqParts[i];
        return true;
      }
      return part === reqParts[i];
    });

    if (match) {
      // Si el valor es objeto, sustituir {{param}} por el valor real
      const resolved = JSON.parse(
        JSON.stringify(value).replace(/\{\{(\w+)\}\}/g, (_, k) => params[k] ?? `{{${k}}}`),
      );
      res.json(resolved);
      return;
    }
  }

  next();
});

export default router;
