import { Router, type IRouter } from "express";

const router: IRouter = Router();

interface CacheEntry {
  data: InstagramProfileResponse;
  ts: number;
}

const cache = new Map<string, CacheEntry>();
const CACHE_TTL_MS = 5 * 60 * 1000;

export interface InstagramProfileResponse {
  username: string;
  full_name: string;
  biography: string;
  profile_pic_url: string;
  followers: number;
  following: number;
  posts: number;
  is_verified: boolean;
  url: string;
}

async function fetchFromRapidApi(username: string): Promise<InstagramProfileResponse> {
  const apiKey = process.env.RAPIDAPI_KEY;
  if (!apiKey) throw new Error("RAPIDAPI_KEY env var is not set");

  const url = `https://instagram-scraper-api2.p.rapidapi.com/v1/info?username_or_id_or_url=${encodeURIComponent(username)}`;

  const res = await fetch(url, {
    headers: {
      "X-RapidAPI-Key": apiKey,
      "X-RapidAPI-Host": "instagram-scraper-api2.p.rapidapi.com",
    },
    signal: AbortSignal.timeout(10_000),
  });

  if (res.status === 404) throw new Error("USER_NOT_FOUND");
  if (res.status === 401 || res.status === 403) throw new Error("INVALID_API_KEY");

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`RapidAPI error ${res.status}: ${body.slice(0, 200)}`);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const json = (await res.json()) as any;

  // instagram-scraper-api2 response shape
  const data = json?.data ?? json;

  if (!data?.username) throw new Error("USER_NOT_FOUND");

  return {
    username: String(data.username ?? username),
    full_name: String(data.full_name ?? ""),
    biography: String(data.biography ?? ""),
    profile_pic_url: String(
      data.hd_profile_pic_url_info?.url ??
      data.profile_pic_url_hd ??
      data.profile_pic_url ??
      "",
    ),
    followers: Number(data.follower_count ?? data.edge_followed_by?.count ?? 0),
    following: Number(data.following_count ?? data.edge_follow?.count ?? 0),
    posts: Number(data.media_count ?? data.edge_owner_to_timeline_media?.count ?? 0),
    is_verified: Boolean(data.is_verified ?? false),
    url: `https://www.instagram.com/${data.username ?? username}/`,
  };
}

router.get("/instagram/:username", async (req, res) => {
  const username = (req.params.username ?? "")
    .toLowerCase()
    .replace(/[^a-z0-9._]/g, "");

  if (!username) {
    res.status(400).json({ error: "Invalid username" });
    return;
  }

  const cached = cache.get(username);
  if (cached && Date.now() - cached.ts < CACHE_TTL_MS) {
    res.setHeader("X-Cache", "HIT");
    res.json(cached.data);
    return;
  }

  if (!process.env.RAPIDAPI_KEY) {
    res.status(503).json({
      error: "API not configured. Set the RAPIDAPI_KEY environment variable.",
    });
    return;
  }

  try {
    const profile = await fetchFromRapidApi(username);
    cache.set(username, { data: profile, ts: Date.now() });
    res.setHeader("X-Cache", "MISS");
    res.json(profile);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    req.log.error({ err }, "Instagram fetch failed");

    if (msg === "USER_NOT_FOUND") {
      res.status(404).json({ error: "Instagram user not found" });
      return;
    }
    if (msg === "INVALID_API_KEY") {
      res.status(401).json({ error: "Invalid RapidAPI key" });
      return;
    }
    res.status(500).json({ error: `Failed to fetch Instagram profile: ${msg}` });
  }
});

export default router;
