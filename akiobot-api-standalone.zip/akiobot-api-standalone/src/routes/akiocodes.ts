import { Router, type IRouter } from "express";

const router: IRouter = Router();

const BASE = "https://akiomae.xyz/Akiocodes_app";

const HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  Accept: "text/html,application/xhtml+xml,*/*;q=0.9",
  "Accept-Language": "es-ES,es;q=0.9",
};

interface CacheEntry {
  data: UserProfile;
  ts: number;
}
const cache = new Map<string, CacheEntry>();
const CACHE_TTL_MS = 3 * 60 * 1000;

export interface UserProfile {
  username: string;
  avatar: string;
  repositorios: number;
  seguidores: number;
  siguiendo: number;
  repo_mas_popular: string;
}

/* ── Search ── */
interface SearchUser {
  id: string;
  username: string;
  avatar_url: string;
  repositories_count: number;
}

async function searchUser(username: string): Promise<SearchUser | null> {
  const res = await fetch(`${BASE}/`, {
    method: "POST",
    headers: {
      ...HEADERS,
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
    },
    body: `action=search&query=${encodeURIComponent(username)}`,
    signal: AbortSignal.timeout(10_000),
  });
  if (!res.ok) return null;
  const json = (await res.json()) as { success: boolean; results: SearchUser[] };
  if (!json.success || !json.results?.length) return null;
  return (
    json.results.find((u) => u.username?.toLowerCase() === username.toLowerCase()) ??
    json.results.find((u) => !!u.username) ??
    null
  );
}

/* ── Profile page ── */
async function scrapeProfile(userId: string): Promise<{
  avatar: string;
  seguidores: number;
  siguiendo: number;
  repoIds: string[];
}> {
  const res = await fetch(`${BASE}/profile/?id=${encodeURIComponent(userId)}`, {
    headers: HEADERS,
    signal: AbortSignal.timeout(10_000),
  });
  if (!res.ok) return { avatar: "", seguidores: 0, siguiendo: 0, repoIds: [] };

  const html = await res.text();

  const avatarMatch = html.match(/<img\s+src="([^"]+)"\s+alt="[^"]+"\s+class="profile-avatar"/);
  const avatar = avatarMatch?.[1] ?? "";

  const numEl = (id: string) => {
    const m = html.match(new RegExp(`id=["']${id}["'][^>]*>\\s*([\\d,]+)`, "i"));
    return m ? parseInt(m[1].replace(/,/g, ""), 10) : 0;
  };

  const ids = new Set<string>();
  for (const m of html.matchAll(/\/repository\/\?id=(repo_[a-z0-9_]+)/gi)) ids.add(m[1]);

  return {
    avatar,
    seguidores: numEl("followers-count"),
    siguiendo: numEl("following-count"),
    repoIds: [...ids],
  };
}

/* ── Most liked repo ── */
async function getMostPopularRepoUrl(repoIds: string[]): Promise<string> {
  if (!repoIds.length) return "";

  const results = await Promise.all(
    repoIds.map(async (id) => {
      try {
        const res = await fetch(`${BASE}/repository/?id=${id}`, {
          headers: HEADERS,
          signal: AbortSignal.timeout(8_000),
        });
        if (!res.ok) return { id, likes: 0 };
        const html = await res.text();
        const m = html.match(/const repository\s*=\s*(\{[\s\S]+?\});/);
        if (!m) return { id, likes: 0 };
        const data = JSON.parse(m[1]) as { likes_count?: number };
        return { id, likes: data.likes_count ?? 0 };
      } catch {
        return { id, likes: 0 };
      }
    }),
  );

  results.sort((a, b) => b.likes - a.likes);
  return `${BASE}/repository/?id=${results[0].id}`;
}

/* ── Route ── */
router.get("/user/:username", async (req, res) => {
  const username = (req.params.username ?? "").trim();
  if (!username) {
    res.status(400).json({ error: "Debes proporcionar un nombre de usuario" });
    return;
  }

  const key = username.toLowerCase();
  const cached = cache.get(key);
  if (cached && Date.now() - cached.ts < CACHE_TTL_MS) {
    res.setHeader("X-Cache", "HIT");
    res.json(cached.data);
    return;
  }

  try {
    const user = await searchUser(username);
    if (!user) {
      res.status(404).json({ error: `Usuario "${username}" no encontrado en AkiomaeCodes` });
      return;
    }

    const [profile] = await Promise.all([scrapeProfile(user.id)]);
    const repo_mas_popular = await getMostPopularRepoUrl(profile.repoIds);

    const data: UserProfile = {
      username: user.username,
      avatar: profile.avatar || user.avatar_url,
      repositorios: user.repositories_count,
      seguidores: profile.seguidores,
      siguiendo: profile.siguiendo,
      repo_mas_popular,
    };

    cache.set(key, { data, ts: Date.now() });
    res.setHeader("X-Cache", "MISS");
    res.json(data);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    req.log.error({ err }, "Akiocodes fetch failed");
    res.status(500).json({ error: `Error al obtener el perfil: ${msg}` });
  }
});

export default router;
